WEBSITE: https://hazure03.neocities.org
BANDCAMP: h4zur3.bandcamp.com

STABS////////////
 - Created from a variety of random song / video game sound samples. None are tuned. Slight EQ to reduce intense low/high frequencies, increased gain with limiter.

Thanks for checking out my stuff!

(Dec 2024)